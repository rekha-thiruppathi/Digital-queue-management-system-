
package com.Digital.Queue.Digital.Queue;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QueueTokenRepository extends JpaRepository<QueueToken, Integer> {
}

