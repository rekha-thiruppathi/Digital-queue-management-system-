
package com.Digital.Queue.Digital.Queue;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/queue")
@CrossOrigin(origins = "*")
public class QueueController {

    private final QueueTokenRepository repository;

    public QueueController(QueueTokenRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<QueueToken> getAllTokens() {
        return repository.findAll();
    }

    @PostMapping
    public QueueToken createToken(@RequestBody Map<String, String> data) {
        String name = data.get("studentName");
        String service = data.get("serviceName");

        int nextToken = (int) repository.count() + 1;

        QueueToken token = new QueueToken(name, service, nextToken);

        return repository.save(token);
    }

    @GetMapping("/stats")
    public Map<String, Long> getQueueStats() {
        Map<String, Long> stats = new HashMap<>();

        List<QueueToken> tokens = repository.findAll();

        stats.put("totalTokens", (long) tokens.size());

        long waitingCount = tokens.stream()
                .filter(token -> "Waiting".equals(token.getStatus()))
                .count();

        stats.put("waitingTokens", waitingCount);

        return stats;
    }
    @PutMapping("/{id}/status")
public QueueToken updateStatus(
        @PathVariable int id,
        @RequestBody Map<String, String> data) {

    QueueToken token = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Token not found"));

    token.setStatus(data.get("status"));

    return repository.save(token);
}

@PutMapping("/{id}/call")
public QueueToken callNextToken(@PathVariable int id) {

    QueueToken token = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Token not found"));

    token.setStatus("Serving");

    return repository.save(token);
}
}
