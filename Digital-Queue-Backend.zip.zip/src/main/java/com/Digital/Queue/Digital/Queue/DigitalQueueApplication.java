package com.Digital.Queue.Digital.Queue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalQueueApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalQueueApplication.class, args);
	}

}
