
package com.Digital.Queue.Digital.Queue;

import jakarta.persistence.*;

@Entity
@Table(name = "queue_tokens")
public class QueueToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "student_name")
    private String studentName;

    @Column(name = "service_name")
    private String serviceName;

    @Column(name = "token_number")
    private int tokenNumber;

    private String status;

    public QueueToken() {
    }

    public QueueToken(String studentName, String serviceName, int tokenNumber) {
        this.studentName = studentName;
        this.serviceName = serviceName;
        this.tokenNumber = tokenNumber;
        this.status = "Waiting";
    }

    public int getId() {
        return id;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public int getTokenNumber() {
        return tokenNumber;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
    this.status = status;
}
}

