package com.Digital.Queue.Digital.Queue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalQueueApplicationTests {

	@Test
	void contextLoads() {
	}

}
